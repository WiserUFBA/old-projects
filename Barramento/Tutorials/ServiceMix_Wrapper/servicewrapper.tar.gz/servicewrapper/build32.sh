#!/bin/sh

export JAVA_HOME="/opt/jdk"

echo
echo "Wrapper Build System"
echo "--------------------"

if [ "$WRAPPER_TOOLS" = "" ] ; then
    WRAPPER_TOOLS=/opt/ant
fi

# Make sure our own copy of Ant is used even if the user has defined their own.
ANT_HOME=$WRAPPER_TOOLS

chmod u+x $WRAPPER_TOOLS/bin/antRun
chmod u+x $WRAPPER_TOOLS/bin/ant

$WRAPPER_TOOLS/bin/ant -logger org.apache.tools.ant.NoBannerLogger -emacs -Dtools.dir=$WRAPPER_TOOLS -Dbits=32 $@ 
